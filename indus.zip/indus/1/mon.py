# Monoalphabetic cipher -Additive cipher

def encrypt (message, key):

    cipher=""

    for i in message:

        if i.isupper ():

            cipher+=chr((ord(i)+key-65)%26+65)

        elif i.islower():

            cipher+=chr((ord(i)+key-97)%26+97)

        else:

            cipher+=""
    return cipher

message=input("Enter plain text:")

key=input("Enter The key:")

if key.isupper ():

    key=ord (key)-65

elif key.islower():

    ey=ord (key)-97

else:

    key=int (key)

print("Cipher text:",encrypt (message, key))

