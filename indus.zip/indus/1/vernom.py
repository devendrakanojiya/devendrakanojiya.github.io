# Vernam Cipher

def stringEncryption (text, key):

    ciphertext=""
    cipher=[]

    for i in range (len (key)):

        cipher.append(ord (text[i])-ord ('A')+ord (key[i])-ord ('A'))

    for i in range (len (key)):

        if cipher[i]>25: cipher[i]=cipher[i]-26

    for i in range (len (key)):

        x=cipher[i]+ord('A')

        ciphertext+=chr(x)

    return ciphertext

plaintext="HelloTycs" 
key="MoneyBank"

enrypttext=stringEncryption (plaintext.upper(), key.upper())
print("Cipher text is:",enrypttext)



