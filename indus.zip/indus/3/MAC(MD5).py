import hashlib

# Take input from the user
message = input("Enter the message to encrypt using MD5: ")

# Calculate MD5 hash
result = hashlib.md5(message.encode())

# Printing the hexadecimal representation of the hash digest.
print("The hexadecimal equivalent of the hash is:", end=" ")
print(result.hexdigest())
