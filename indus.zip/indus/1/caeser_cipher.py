def caesar_cipher(text, shift, encrypt=True):
    result = ''
    for char in text:
        if char.isalpha():
            start = ord('A') if char.isupper() else ord('a')
            if encrypt:
                result += chr((ord(char) - start + shift) % 26 + start)
            else:
                result += chr((ord(char) - start - shift) % 26 + start)
        else:
            result += char
    return result

plaintext = input("Enter The Plain Text ")
shift_value = int(input("Enter of number Of shift "))

# Encryption
encrypted_text = caesar_cipher(plaintext, shift_value, encrypt=True)
print(f"Original: {plaintext}")
print(f"Encrypted: {encrypted_text}")

# Decryption
decrypted_text = caesar_cipher(encrypted_text, shift_value, encrypt=False)
print(f"Decrypted: {decrypted_text}")
