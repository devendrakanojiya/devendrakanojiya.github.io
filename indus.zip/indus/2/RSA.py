
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
import binascii

# Generate key pair
keyPair = RSA.generate(1024)
pubKey = keyPair.publickey()

# Display public key
print(f"Public key: (n={hex(pubKey.n)}, e={hex(pubKey.e)})")
pubKeyPEM = pubKey.export_key()
print(pubKeyPEM.decode('ascii'))

# Display private key
print(f"Private key: (n={hex(pubKey.n)}, d={hex(keyPair.d)})")
privKeyPEM = keyPair.export_key()
print(privKeyPEM.decode('ascii'))

# Encryption
msg = input("Enter the Message: ")
encryptor = PKCS1_OAEP.new(pubKey)
encrypted = encryptor.encrypt(msg.encode('utf-8'))
print("Encrypted:", binascii.hexlify(encrypted))

# Decryption
decryptor = PKCS1_OAEP.new(keyPair)
decrypted = decryptor.decrypt(encrypted).decode('utf-8')
print("Decrypted:", decrypted)


# CMD-> cd C:\Users\sahil\AppData\Local\Programs\Python\Python311\Lib\site-packages
#pip install pycryptodome
