from random import randint

if __name__ == '__main__':
    P = int(input("Enter a very large prime number"))
    G = int(input("Enter a Generator , number smaller than P"))

    print('The Value of P is: %d' % P)
    print('The Value of G is: %d' % G)

    a = 4
    print('Secret Number for Alice is: %d' % a)
    x = int(pow(G, a, P))  # (G ** a) % P

    b = 6
    print('Secret Number for Bob is: %d' % b)
    y = int(pow(G, b, P))  # (G ** b) % P

    ka = int(pow(y, a, P))  # (y ** a) % P
    kb = int(pow(x, b, P)) # (x ** b) % P

    print('Secret key for Alice is: %d' % ka)
    print('Secret Key for Bob is: %d' % kb)
