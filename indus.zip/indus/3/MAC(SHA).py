import hashlib

user_input = input("Enter the value to encode: ")
result = hashlib.sha1(user_input.encode())

print("The hexadecimal equivalent of SHA1 is:")
print(result.hexdigest())
